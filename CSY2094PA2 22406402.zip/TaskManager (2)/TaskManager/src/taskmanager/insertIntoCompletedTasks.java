    /*
     * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
     * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
     */
    // In the javaclasses package

    package taskmanager;

    import java.sql.Connection;
    import java.sql.PreparedStatement;
    import java.sql.SQLException;
    import viewScreen.Connenction;

    public class insertIntoCompletedTasks {

        public static void insertIntoCompletedTasks(int taskId, String taskDescription, java.sql.Date dueDate) {
            try {
                String query = "INSERT INTO CompletedTasks (ID, TaskDescription, DueDate) VALUES (?, ?, ?)";
                try (Connection con = Connenction.getCon(); PreparedStatement pst = con.prepareStatement(query)) {
                    pst.setInt(1, taskId);
                    pst.setString(2, taskDescription);
                    pst.setDate(3, dueDate);

                    int rowsAffected = pst.executeUpdate();

                    if (rowsAffected > 0) {
                        System.out.println("Task marked as completed and inserted into CompletedTasks.");
                    } else {
                        System.out.println("Failed to insert task into CompletedTasks.");
                    }
                }
            } catch (SQLException e) {
                // Handle the exception appropriately, e.g., log it or show an error message
                e.printStackTrace();
            }
        }
    }
